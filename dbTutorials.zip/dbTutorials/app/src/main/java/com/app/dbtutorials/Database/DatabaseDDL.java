package com.app.dbtutorials.Database;


/*
 * SQL DDL Commands
 * Data Definition Language (DDL) statements or commands are used to create and modify the structure of a database and database objects.
 *
 * Some commands of DML are:
 *
 * CREATE – Create a database, table, triggers, index, functions, stored procedures, etc.
 * DROP – This SQL DDL command helps to delete objects. For example, delete tables, delete a database, etc.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseDDL extends SQLiteOpenHelper
{
    // CREATE DATABASE CONSTRUCTOR HERE :
    public DatabaseDDL(Context context)
    {
        // this will allow us to access this file throughout the application.
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // 1. CREATE THE DATABASE :
    private static final String DATABASE_NAME = "tutorials.db";

    // 2. SET THE DATABASE VERSION :
    private static final int DATABASE_VERSION = 1;

    // 3. CREATE DATABASE TABLES HERE :
    public static final String TABLE_NAME = "database_table";

    // 4. CREATE TABLE COLUMNS :
    public static final String COL_1 = "id"; // this is going to be the primary key.
    public static final String COL_2 = "col_2";
    public static final String COL_3 = "col_3";
    public static final String COL_4 = "col_4";
    public static final String COL_5 = "col_5";

    // 4. CREATE AN SQL STATEMENT TO BE EXECUTED HERE :
    public static final String CREATE_TABLE_QUERY = "CREATE TABLE " + TABLE_NAME + "( "
            + COL_1 + "INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_2 + " TEXT, "
            + COL_3 + " TEXT, " + COL_4 + " TEXT, " + COL_5 + " TEXT" + ");";


    // CREATE TABLE HERE (DDL COMMAND -- CREATE):
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(CREATE_TABLE_QUERY);
    }

    // DROP THE TABLE IF IT EXISTS HERE (DDL COMMAND -- DROP):
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

}
