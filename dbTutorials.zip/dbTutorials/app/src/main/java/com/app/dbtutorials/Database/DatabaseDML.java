package com.app.dbtutorials.Database;

/*
 * Data Manipulation Language (DML) statements or commands are used for managing data within tables. Some commands of DML are:
 *
 * Some commands of DML are:
 *
 * SELECT – retrieve data from the a database
 * INSERT – insert data into a table
 * UPDATE – updates existing data within a table
 * DELETE – deletes all records from a table, the space for the records remain
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseDML
{
    // CREATE GLOBAL VARIABLES HERE :
    // Context is a service that allows access to resources.
    private DatabaseDDL DATABASE;
    private Context GRANT_ACCESS_TO;
    private SQLiteDatabase database; // helps us write to the database.

    // CREATE CONSTRUCTOR HERE :
    public DatabaseDML(Context context)
    {
        this.GRANT_ACCESS_TO = context;
    }

    // When opening the database, make sure to handle errors :
    public DatabaseDML open() throws SQLException
    {
        DATABASE = new DatabaseDDL(GRANT_ACCESS_TO); // asking for access to the database.
        database = DATABASE.getWritableDatabase(); // helps use write to the database.
        return this;
    }

    // CREATE INSERT SQL METHOD HERE :
    // Content values store values that are to be processed.
    public void INSERT(String column1, String column_2)
    {
        ContentValues storeValue = new ContentValues();
        storeValue.put(DatabaseDDL.COL_2, column1); // put column_1 value in table in, in column, in the database.
        storeValue.put(DatabaseDDL.COL_3, column_2); // put column_2 value in table in, in column, in the database.
        database.insert(DatabaseDDL.TABLE_NAME, null, storeValue);
    }
}